---
layout: post
title: About
permalink: /about/
---

Krishna is a minimal Jekyll theme suitable for code based blogs and project showcase.

I would like to thank,

Ankur Gupta for his Trio theme: [https://github.com/ankur-gupta/trio](https://github.com/ankur-gupta/trio)

Rab Rennie for his CSS only Expanding Menu: [http://codepen.io/Rabrennie/pen/WogNvV](http://codepen.io/Rabrennie/pen/WogNvV)

For more themes visit - [**Jekyll Themes**](https:jekyll-themes.com){: target="_blank"}

For Jekyll tutorials visit - [**Webjeda**](https://blog.webjeda.com/){: target="_blank"}

**Does the theme deserve a star?**

<a class="github-button" href="https://github.com/sharu725/krishna" data-style="mega" data-count-href="/sharu725/krishna/stargazers" data-count-api="/repos/sharu725/krishna#stargazers_count" data-count-aria-label="# stargazers on GitHub" aria-label="Star sharu725/krishna on GitHub">Star</a>
<script async defer src="https://buttons.github.io/buttons.js"></script>